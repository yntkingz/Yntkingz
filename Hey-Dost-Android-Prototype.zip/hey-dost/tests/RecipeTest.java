import in.heydost.Recipe;
public class RecipeTest {
 public static void main(String[] args){
  var s=Recipe.parse("OPEN org.telegram.messenger\nTYPE ${name}\nWAIT 1000\nBACK", "मेरा चैनल");
  if(s.size()!=4||!s.get(1).value.equals("मेरा चैनल"))throw new AssertionError("parameter");
  bad("CLICK button", "");bad("OPEN telegram", "");bad("OPEN org.telegram.messenger\nWAIT 99999", "");bad("OPEN org.telegram.messenger\nTYPE ${name}", "");bad("OPEN org.telegram.messenger\nDELETE everything", "");
  if(Recipe.parse("# note\r\nOPEN org.telegram.messenger\r\nASSERT Welcome", "").size()!=2)throw new AssertionError("CRLF");
  if(Recipe.parse("OPEN org.telegram.messenger\nTYPE ${name}", "a\nBACK").size()!=2)throw new AssertionError("parameter injection");
  System.out.println("Recipe tests passed");
 }
 static void bad(String s,String n){try{Recipe.parse(s,n);throw new AssertionError("invalid recipe accepted");}catch(IllegalArgumentException expected){}}
}
