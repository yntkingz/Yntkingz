package in.heydost;
import android.app.*;import android.os.*;import android.content.*;import android.speech.RecognizerIntent;import android.provider.Settings;import android.widget.*;import java.util.*;
public class MainActivity extends Activity {
 EditText command, script, parameter, appPackage; TextView status; android.content.SharedPreferences prefs;
 @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("dost",0);
  LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(24,30,24,24);ScrollView scroll=new ScrollView(this);scroll.addView(l);setContentView(scroll);
  TextView title=new TextView(this);title.setText("Hey Dost · सीखने वाला सहायक");title.setTextSize(23);l.addView(title);
  status=new TextView(this);status.setText("यह शुरुआती प्रोटोटाइप है। आवाज़ से सेव की हुई कमांड चलती है; खुली लाइव बातचीत अभी नहीं है।");l.addView(status);
  button(l,"1. नियंत्रण की अनुमति",()->new AlertDialog.Builder(this).setMessage("Hey Dost ऐप के बटन और टेक्स्ट देख सकेगा तथा आपके शुरू किए काम में टैप और टाइप कर सकेगा। रिकॉर्डिंग केवल ‘सिखाएँ’ चालू होने पर होती है। स्क्रीन या कदम कोई AI सर्वर पर नहीं भेजे जाते। आवाज़ पहचानने वाला फोन का प्रदाता ऑडियो ऑनलाइन भेज सकता है।").setPositiveButton("सेटिंग खोलें",(d,w)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))).setNegativeButton("रद्द",null).show());
  appPackage=field(l,"ऐप package, जैसे org.telegram.messenger",prefs.getString("package","org.telegram.messenger"));
  command=field(l,"कमांड का नाम, जैसे चैनल बनाओ",prefs.getString("command","चैनल बनाओ"));
  parameter=field(l,"नए चैनल का नाम / ${name}","");
  button(l,"2. मुझे करके दिखाएँ (रिकॉर्डिंग)",()->{DostService s=DostService.instance;if(s==null){message("पहले नियंत्रण की अनुमति दें");return;}s.teach(appPackage.getText().toString().trim());});
  TextView help=new TextView(this);help.setText("रिकॉर्डिंग रोककर यहाँ कदम जाँचें। हर नया नाम दोहराने के लिए TYPE वाली पंक्ति में ${name} लिखें।");l.addView(help);
  script=field(l,"सिखाए हुए कदम",prefs.getString("script","OPEN org.telegram.messenger\n# पहले रिकॉर्ड करके अपना तरीका सिखाएँ"));script.setMinLines(7);script.setGravity(48);
  button(l,"3. कमांड याद रखो",()->save());
  button(l,"बोलकर कमांड दें",()->{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"hi-IN");i.putExtra(RecognizerIntent.EXTRA_PROMPT,"सेव की हुई कमांड का नाम बोलें");try{startActivityForResult(i,10);}catch(ActivityNotFoundException e){message("फोन में आवाज़ पहचानने वाला ऐप उपलब्ध नहीं है; नीचे वाला बटन दबाएँ");}});
  button(l,"कमांड चलाएँ",()->review());button(l,"काम रोकें",()->{if(DostService.instance!=null)DostService.instance.stop("रोक दिया");});
 }
 EditText field(LinearLayout l,String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setText(value);l.addView(e);return e;}
 void button(LinearLayout l,String t,Runnable r){Button b=new Button(this);b.setText(t);l.addView(b);b.setOnClickListener(v->r.run());}
 void message(String m){status.setText(m);Toast.makeText(this,m,Toast.LENGTH_LONG).show();}
 boolean save(){try{Recipe.parse(script.getText().toString(),"नमूना");String c=command.getText().toString().trim();if(c.isEmpty())throw new IllegalArgumentException("कमांड का नाम लिखें");prefs.edit().putString("command",c).putString("script",script.getText().toString()).putString("package",appPackage.getText().toString().trim()).apply();message("कमांड याद रख ली");return true;}catch(Exception e){message(e.getMessage());return false;}}
 void review(){try{List<Recipe.Step> steps=Recipe.parse(script.getText().toString(),parameter.getText().toString());StringBuilder text=new StringBuilder();for(Recipe.Step s:steps)text.append(s.op).append(" ").append(s.value).append('\n');new AlertDialog.Builder(this).setTitle("यह काम चलाएँ?").setMessage(text.toString()).setPositiveButton("चलाएँ",(d,w)->{DostService s=DostService.instance;if(s==null)message("पहले अनुमति दें");else s.run(steps);}).setNegativeButton("रद्द",null).show();}catch(Exception e){message(e.getMessage());}}
 @Override protected void onResume(){super.onResume();String pending=prefs.getString("pending",null);if(pending!=null){script.setText(pending);prefs.edit().remove("pending").apply();message("रिकॉर्डिंग आ गई। कदम जाँचें, फिर याद रखें।");}}
 @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==10&&result==RESULT_OK&&data!=null){ArrayList<String> words=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(words!=null&&!words.isEmpty()){String said=words.get(0).trim();if(said.equalsIgnoreCase(prefs.getString("command",""))) {script.setText(prefs.getString("script",""));review();}else message("सुना: "+said+"। सेव की हुई कमांड का नाम बोलें: "+prefs.getString("command",""));}}}
}
