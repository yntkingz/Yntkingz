package in.heydost;
import java.util.*;
public final class Recipe {
 public static final class Step { public final String op, value; Step(String a,String b){op=a;value=b;} }
 public static List<Step> parse(String script, String name) {
  List<Step> out=new ArrayList<>();
  for(String line:script.split("\r?\n")) { 
   String s=line.trim(); if(s.isEmpty()||s.startsWith("#"))continue;
   int i=s.indexOf(' '); String op=(i<0?s:s.substring(0,i)).toUpperCase(Locale.ROOT);
   String v=i<0?"":s.substring(i+1).trim();
   if(!Arrays.asList("OPEN","CLICK","TYPE","BACK","WAIT","ASSERT").contains(op))throw new IllegalArgumentException("Unknown step: "+op);
   if(!op.equals("BACK")&&v.isEmpty())throw new IllegalArgumentException("Missing value: "+op);
   if(v.contains("${name}")&&(name==null||name.trim().isEmpty()))throw new IllegalArgumentException("Task needs a name");
   if(op.equals("WAIT")){int ms=Integer.parseInt(v);if(ms<100||ms>10000)throw new IllegalArgumentException("WAIT: 100–10000 ms");}
   if(op.equals("OPEN")&&!v.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+"))throw new IllegalArgumentException("OPEN needs an Android package name");
   out.add(new Step(op,v.replace("${name}",name==null?"":name)));
  }
  if(out.isEmpty()||out.size()>100)throw new IllegalArgumentException("Use 1–100 steps");
  if(!out.get(0).op.equals("OPEN"))throw new IllegalArgumentException("First step must be OPEN");
  return out;
 }
}
