# Hey Dost — Android teach-and-replay prototype

यह **सोर्स प्रोजेक्ट** है, इंस्टॉल होने वाला APK नहीं। इस वातावरण में Android SDK/Gradle नहीं होने के कारण पूरा ऐप compile या फोन पर test नहीं किया गया। सिर्फ recipe parser के standalone Java checks और XML/archive checks किए गए हैं। इसे पूर्ण AI या सभी ऐप्स के विश्वसनीय नियंत्रण के रूप में न समझें।

## Cloud APK build
`.github/workflows/android-apk.yml` तैयार है। Project की contents repository root पर अपलोड होने के बाद GitHub Actions में Build Hey Dost APK workflow चलेगा। सफल run के Hey-Dost-APK artifact में APK मिलेगा। इस चैट में GitHub integration ने write प्रयास 403 से रोका; इसलिए workflow अभी repository में upload या run नहीं हुआ है।


## क्या बनाया गया
- हिंदी आवाज़ से सेव की हुई कमांड चुनना; पहचाने गए शब्दों का exact match।
- Text-to-speech में काम शुरू/रुकने की सूचना। यह खुली live conversation नहीं है।
- अपनी पसंद के Android ऐप में Teach mode: आपके clicks और non-password text changes को रिकॉर्ड करना।
- तरीका बदलकर फिर वही कदम चलाना; `${name}` से हर बार नया नाम देना।
- Floating Stop button, किसी दूसरे ऐप में पहुँचने पर काम रोकना/timeout, ambiguous controls पर रुकना।
- एक सेव किया हुआ तरीका; उसे नए तरीके से बदल सकते हैं। डेटा फोन की app-private storage में।

यह machine learning/LLM नहीं है: “सीखना” यहाँ आपके दिखाए हुए कदम याद रखना है। स्वतः reasoning, सभी commands समझना, screenshots की vision, सतत live बातचीत, satellite connectivity शामिल नहीं हैं। इन सुविधाओं के लिए अगला development चरण, AI API/service और वास्तविक फोन पर परीक्षण चाहिए।

## APK कैसे बनाएँ (PC चाहिए)
1. Android Studio स्थापित करें, इस ZIP को extract करके `hey-dost` folder खोलें।
2. JDK 17, Android SDK 35 तथा Gradle 8.9 चुनें; Gradle sync होने दें। Dependency downloads के लिए इंटरनेट चाहिए।
3. Build menu में APK बनाने का विकल्प चुनें। Output: `app/build/outputs/apk/debug/app-debug.apk`।
4. अपने Android 8+ फोन में APK install करें। Hey Dost खोलें और “नियंत्रण की अनुमति” पढ़कर Accessibility settings में service enable करें। फोन यदि sideloaded app की restricted settings रोकता है तो उस फोन की app-info settings के अनुसार अनुमति देनी होगी।

## Telegram में सिखाना
1. Telegram में लॉगिन खुद करें; Hey Dost को login/OTP/password नहीं देना है। ऐप package आमतौर पर `org.telegram.messenger` है; दूसरे Telegram clients अलग होते हैं।
2. कमांड नाम जैसे `चैनल बनाओ` लिखें; “मुझे करके दिखाएँ” दबाएँ।
3. Telegram में स्वयं नया चैनल बनाने के steps करें, फिर floating “रिकॉर्डिंग समाप्त” दबाएँ। यह वास्तविक काम है: demo में भी चैनल बन सकता है।
4. रिकॉर्डिंग देखकर अनावश्यक keyboard/duplicate taps हटाएँ। जिस TYPE line में channel name आया है उसे `TYPE ${name}` कर दें। रिकॉर्डिंग navigation gestures/Back या screen scroll capture नहीं करती; जरूरत हो तो `BACK` जोड़ें।
5. Name field में अगला नाम लिखें, “कमांड याद रखो”, फिर कमांड बोलें और steps preview से चलाएँ।
6. Telegram में बनी चीज खुद verify करें। UI भाषा, ऐप update, inaccessible icons, multiple same-label controls, keyboard and OEM restrictions के कारण steps बदलने पड़ सकते हैं। नाम/DP/post copying का तैयार tested workflow शामिल नहीं है।

## Step syntax
हर पंक्ति एक कदम। शुरुआत `OPEN package.name` से।
```
OPEN org.telegram.messenger
# नीचे उदाहरण है; आपके Telegram में बटन का exact label/ID जाँचें
CLICK New Channel
TYPE ${name}
```
`CLICK exact visible text` या `CLICK ID=package:id/view`, `TYPE text`, `BACK`, `WAIT 1000`, `ASSERT exact visible text`। सिर्फ visible controls; password fields छोड़े जाते हैं। TYPE focused editable field या अकेले visible editable field में लिखता है। CLICK ambiguous होने पर रुकता है। WAIT 100–10000 milliseconds।

## Privacy and practical limits
App में Internet या microphone permission नहीं है: voice entry Android के installed recognizer को सौंपता है; वह provider audio online process कर सकता है। Screen data Hey Dost कोई server पर नहीं भेजता। Teach mode में उस target app के non-password fields का text private storage में आ सकता है; संवेदनशील जानकारी रिकॉर्ड न करें। Accessibility अनुमति Settings से बंद कर सकते हैं; Clear app storage से saved method मिटेगा। No root, no hidden control, no lock-screen bypass. Locked screen पर काम भरोसेमंद नहीं है।

## Development validation
`javac -d /tmp/dost-test app/src/main/java/in/heydost/Recipe.java tests/RecipeTest.java && java -cp /tmp/dost-test RecipeTest`

References:
- https://developer.android.com/guide/topics/ui/accessibility/service
- https://developer.android.com/reference/android/speech/RecognizerIntent

## आगे वास्तविक AI जोड़ने के लिए
पहले device replay स्थिर करें। उसके बाद authenticated backend पर voice conversation और screen-aware planning जोड़ें। Provider/API key इस project में hardcode नहीं की गई है। किसी भी screenshot/text upload से पहले user disclosure तथा session consent UI जोड़ें। नई autonomy को step budget, allowed apps और stop control के साथ verify करें।
